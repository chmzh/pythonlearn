from tkinter import *
T = Tk()
Button(T, text='sss', command=T.quit).pack()
T.mainloop()
