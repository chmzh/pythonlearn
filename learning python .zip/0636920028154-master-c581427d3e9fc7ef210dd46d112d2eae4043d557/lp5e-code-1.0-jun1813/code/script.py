#!python3
print('I am script.py')       # code a program here 