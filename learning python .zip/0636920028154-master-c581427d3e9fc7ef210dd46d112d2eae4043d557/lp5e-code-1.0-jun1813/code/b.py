import c     # File b.py
Y = 222
