from __future__ import print_function
print(1, 2, 3)