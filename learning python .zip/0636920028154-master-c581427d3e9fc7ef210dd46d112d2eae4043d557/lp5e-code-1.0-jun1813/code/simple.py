print('hello')
spam = 1                   # Initialize variable
